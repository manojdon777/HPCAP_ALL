package exam;

import java.util.Date;

public class Product {
    public
    String name;
    int quantity;
    int MRP;
    Date expiryDate;
    public Product(String name, int quantity, int MRP, Date expiryDate){
        this.name = name;
        this.quantity = quantity;
        this.MRP = MRP;
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "Name : " + name + " Quantity : " + quantity + " MRP : " + MRP + " Expiry date : " + expiryDate;
    }
}
