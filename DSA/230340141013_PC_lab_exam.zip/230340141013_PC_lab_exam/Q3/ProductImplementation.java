package exam;

import exam.exception.MyException;

import java.util.Date;

public class ProductImplementation {
    Product productArray[] = new Product[5];
    int top = -1;
    public void add(Product product){
        boolean flag = false;
        for (int i=0;i<top;i++){
            if(product.name.equals(productArray[i].name)){
                productArray[i].quantity++;
                flag = true;
            }
        }
        if(flag == false){
            top++;
            productArray[top].name = product.name;
        }
    }
    public void get(Product product){
        boolean flag = false;
        try{
            for (int i = 0; i < top; i++) {
                if(product.name.equals(productArray[i])) {
                    productArray[i].quantity--;
                }
            }
            if(flag == true)
                throw new MyException("Error");
        }catch (MyException e){

        }
    }
    public void show(){
        for (int i = 0; i < top; i++) {
            if(productArray[i].quantity > 0){
                productArray.toString();
            }
        }
    }
    public void showExpired(){
        for (int i = 0; i < top; i++) {
            if(productArray[i].expiryDate.compareTo(new Date(2023,3,3)) > 0 ){
                productArray.toString();
            }
        }

    }
    public void deleteExpired(){
        for (int i = 0; i < top; i++) {
            if(productArray[i].expiryDate.compareTo(new Date(2023,3,3)) > 0 ){
                productArray[i] = null;
            }
        }

    }
}
