#include<stdio.h>
#define MAX 5
int stack[MAX];
int top = -1;
void push(int data){
	if(top == MAX - 1){
		printf("\nStack is OVERFLOW\n");
		return;
	}
	else{
		top++;
		stack[top] = data;
	}

}
int pop(){
	if(top == -1){
		printf("STack is UNDERFLOW\n");
		return -1;
	}
	else{
		int data = stack[top];
		top--;
		return data;
	}
}
void display(){
	if(top == -1)
		printf("Stack is Empty\n");
	else{
		for (int i = 0; i<=top; i++){
			printf("%d ", stack[i]);
		}
	}
	printf("\n");
}
void showMin(){
	int min = 999999999;
	for (int i = 0; i <= top; ++i)
	{
		min = min < stack[i] ? min : stack[i];
	}
	printf("The min Element is %d\n", min);
}
int main(){

	push(11);
	push(2);
	push(3);
	push(14);
	push(15);
	display();
	showMin();
	printf("Popped item is = %d\n", pop());
	printf("Popped item is = %d\n", pop());
	printf("Popped item is = %d\n", pop());
	display();
	showMin();
	printf("\n");

	return 0;
}