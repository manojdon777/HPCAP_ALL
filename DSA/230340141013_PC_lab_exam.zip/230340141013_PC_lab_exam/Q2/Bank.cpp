#include<iostream>
using namespace std;
class Card{
public:
	int creditLimit;
	int interestLimit;
	void display(){
		cout << "Credit limit is " << creditLimit << endl;
		cout << "Interest limit is " << interestLimit << endl;

	}
};
class Silver : public Card{
public:
	Silver(int creditLimit, int interestLimit){
		this->creditLimit = creditLimit;
		this->interestLimit = interestLimit;
	}
	void display(){
		cout << "Silver card comes with credit limit : " << creditLimit << " and InterestRate: "<< interestLimit << "%" << endl;
	}	
};
class Gold : public Card{
public:
	int discount;
	Gold(int creditLimit, int interestLimit, int discount){
		this->creditLimit = creditLimit;
		this->interestLimit = interestLimit;
		this->discount = discount;
	}
	void display(){
		cout << "Gold card comes with credit limit : " << creditLimit << " and InterestRate: "<< interestLimit <<" and Discount:" << discount << "%" << endl;
	}	
};
class Platinum : public Card{
public:
	int discount;
	int cashBack;
	Platinum(int creditLimit, int interestLimit, int discount, int cashBack){
		this->creditLimit = creditLimit;
		this->interestLimit = interestLimit;
		this->discount = discount;
		this->cashBack = cashBack;
	}
	void display(){
		cout << "Platinum card comes with credit limit : " << creditLimit << " and InterestRate: "<< interestLimit <<" and Discount:" << discount << "% and " << cashBack << " cash back offer" << endl;
	}	
};
void fSilver(){
	int creditLimit;
	int interestLimit;
	cout << "\tEnter creditLimit: ";
	cin >> creditLimit;
	cout << "\tEnter interestLimit: ";
	cin >> interestLimit;
	Silver silver(creditLimit, interestLimit);
	silver.display();
}
void fGold(){
	int creditLimit;
	int interestLimit;
	int discount;
	cout << "\tEnter creditLimit: ";
	cin >> creditLimit;
	cout << "\tEnter interestLimit: ";
	cin >> interestLimit;
	cout << "\tEnter discount: ";
	cin >> discount;
	Gold gold(creditLimit, interestLimit, discount);
	gold.display();
}
void fPlatinum(){
	int creditLimit;
	int interestLimit;
	int discount;
	int cashBack;
	cout << "\tEnter creditLimit: ";
	cin >> creditLimit;
	cout << "\tEnter interestLimit: ";
	cin >> interestLimit;
	cout << "\tEnter discount: ";
	cin >> discount;
	cout << "\tEnter cashBack : ";
	cin >> cashBack;
	Platinum platinum(creditLimit, interestLimit, discount, cashBack);
	platinum.display();
}
int main(){
	int choice;
	while(1){
		cout << "\tChoose card type" << endl;
		cout << "\t\t1. Silver" << endl;
		cout << "\t\t2. Gold" << endl;
		cout << "\t\t3. Platinum" << endl;
		cout << "\t\t4. EXIT" << endl;
		cout << "\tEnter choice : ";
		cin >> choice;
		switch (choice){
		case 1:
			fSilver();
			break;
		case 2:
			fGold();
			break;
		case 3:
			fPlatinum();
			break;
		case 4:
			exit(0);
		default:
			cout << "Enter proper choice" << endl;
		}
	}
	cout << endl;
	return 0;
}